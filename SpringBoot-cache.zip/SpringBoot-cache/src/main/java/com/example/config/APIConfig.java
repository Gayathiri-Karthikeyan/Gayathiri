package com.example.config;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import net.sf.ehcache.config.CacheConfiguration;

@Configuration
@EnableCaching
public class APIConfig extends CachingConfigurerSupport{
	
	
	public net.sf.ehcache.CacheManager ehCasheManager(){
		CacheConfiguration tenSec=new CacheConfiguration();
		tenSec.setName("ten-second-cache");
		tenSec.setMemoryStoreEvictionPolicy("LRU");
		tenSec.setMaxEntriesLocalHeap(1000);
		tenSec.setTimeToLiveSeconds(10);
		
		CacheConfiguration twentySec=new CacheConfiguration();
		twentySec.setName("twenty-second-cache");
		twentySec.setMemoryStoreEvictionPolicy("LRU");
		twentySec.setMaxEntriesLocalHeap(1000);
		twentySec.setTimeToLiveSeconds(20);
		
		net.sf.ehcache.config.Configuration config = new net.sf.ehcache.config.Configuration();
		config.addCache(tenSec);
		config.addCache(twentySec);
		return net.sf.ehcache.CacheManager.newInstance(config);
		
	}
	
	
	
	
	@Bean
	@Override
	public CacheManager cacheManager() {
		return new EhCacheCacheManager(ehCasheManager());
	}

	
	
}
