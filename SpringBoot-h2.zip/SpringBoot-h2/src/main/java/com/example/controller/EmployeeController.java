package com.example.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.dao.EmployeeRepository;
import com.example.exception.ResourceNotFoundException;
import com.example.model.Employee;
import com.example.service.EmployeeService;



@RestController
@RequestMapping("/api/")
public class EmployeeController {
	@Autowired
	private EmployeeService service;
	@Autowired EmployeeRepository repository;
	
	@PostMapping("/saveEmployee")
	public String  saveEmployee(@RequestBody Employee employee,@RequestParam(name="isCacheable")boolean isCacheable) throws InterruptedException {
		
		service.save(employee,isCacheable);
		return "Employee Saved..";
		
	}
	
	
	
	
	@GetMapping("/getAll")
	public List<Employee> getAll(){
		
		return service.findAll();
	}
	
	
	
	
	
	@GetMapping("/getEmployee/{dept}")
	public List<Employee> getEmployeeByDept(@PathVariable String dept){
		return service.findByDept(dept);
		
	}
	
	
	
	@PutMapping("/employee/{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable Integer id,@RequestBody Employee employee){
		
		
		Employee emp=repository.findById(id)
				.orElseThrow(()->new ResourceNotFoundException("Employee not found:"+id));
		emp.setName(employee.getName());
		emp.setDept(employee.getDept());
		emp.setSalary(employee.getSalary());
		
		Employee updatedEmployee=repository.save(emp);
		return ResponseEntity.ok(updatedEmployee);
			
	}
	
	
	
	
	@DeleteMapping("/employee/{id}")
    public ResponseEntity<Map<String,Boolean>> deleteEmployee(@PathVariable Integer id){
		
		
		Employee emp=repository.findById(id)
				.orElseThrow(()->new ResourceNotFoundException("Employee not found:"+id));
	
		
		repository.delete(emp);
		Map<String,Boolean> response=new HashMap<>();
		response.put("Deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
		
	
	
	
}
}

