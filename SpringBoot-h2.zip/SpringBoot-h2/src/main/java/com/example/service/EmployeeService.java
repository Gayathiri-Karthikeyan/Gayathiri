package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.example.dao.EmployeeRepository;
import com.example.model.Employee;

@Service
public class EmployeeService {

	
	@Autowired
	EmployeeRepository repository;
	@CacheEvict(value="twenty-second-cache", key = "'StudentInCache'+#employee.id+#employee.name+#employee.dept+#employee.salary",
			condition = "#isCacheable == null || !#isCacheable", beforeInvocation = true)
	@Cacheable(value="twenty-second-cache", key = "'StudentInCache'+#employee", 
			condition = "#isCacheable != null && #isCacheable")
	public Employee save(Employee employee,boolean isCacheable ) throws InterruptedException {
		// TODO Auto-generated method stub
		Thread.sleep(4000);
		return repository.save(employee);
		
	}
	
	public List<Employee> findAll() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}
	
	public List<Employee> findByDept(String dept) {
		// TODO Auto-generated method stub
		return repository.findByDept(dept);
	}

	
}
