package com.example;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MvcResult;

import com.example.dao.EmployeeRepository;
import com.example.model.Employee;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;





@RunWith(SpringRunner.class)
@SpringBootTest(classes= {TestWebApp.class})
class SpringBootH2ApplicationTests {

	@Test
	void contextLoads() {
	}
	
	
	@MockBean
	private EmployeeRepository repository;
	
	@Test
	public void getUsersTest() {
		
		when(repository.findAll()).thenReturn(Stream
				.of(new Employee(1,"Gayathiri","CSE",20000),new Employee(2,"Nivetha","EEE",40000)).collect(Collectors.toList()));
		
		assertEquals(2,repository.findAll().size());
		
	}
	@Test
	public void getUserByDept() {
		
		String dept="CSE";
		when(repository.findByDept(dept)).thenReturn(Stream
				.of(new Employee(1,"Gayathiri","CSE",20000)).collect(Collectors.toList()));
		assertEquals(1,repository.findByDept(dept).size());
	}
	@Test
	public void saveUser() {
		
		Employee employee=new Employee(1,"Gayathiri","CSE",20000);
		when(repository.save(employee)).thenReturn(employee);
		assertEquals(employee,repository.save(employee));
	}
	@Test
	public void deleteUser() {
		Employee employee=new Employee(1,"Gayathiri","CSE",20000);
		repository.delete(employee);
		verify(repository,times(1)).delete(employee);
	}
	
}
